#!/bin/sh
rm jules-verne.lot
rm jules-verne.lof
rm jules-verne.toc
rm jules-verne.out
rm jules-verne.bbl
rm jules-verne.blg
rm jules-verne.brf
rm *.aux
rm *.log
rm *.bak
rm *~

