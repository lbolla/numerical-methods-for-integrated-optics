#!/bin/sh
rm jules-verne.lot
rm jules-verne.lof
rm jules-verne.toc
rm jules-verne.gls.*
rm jules-verne.losa.*
rm jules-verne.idx
rm jules-verne.ind
rm jules-verne.ilg
rm jules-verne.lol
rm jules-verne.out
rm jules-verne.bbl
rm jules-verne.blg
rm jules-verne.brf
rm jules-verne.tpt
rm *.aux
rm *.log
rm *.bak
rm *~

